package com.shyam.grocery.Activity.Data;

import org.junit.Test;

import static org.junit.Assert.*;

public class ListActivityTest {

    @Test
    public void onCreate() {
    }
}