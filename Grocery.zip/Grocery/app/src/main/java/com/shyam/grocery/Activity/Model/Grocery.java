package com.shyam.grocery.Activity.Model;


public class Grocery {

    private String name;
    private String quantity;
    private String dataIteam;
    private int id;

    public Grocery() {

    }

    public Grocery(String name, String quantity, String dataIteam, int id) {
        this.name = name;
        this.quantity = quantity;
        this.dataIteam = dataIteam;
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getQuantity(){
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getDataIteam() {
        return dataIteam;
    }

    public void setDataIteam(String dataIteam) {
        this.dataIteam = dataIteam;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //public String getQuantity() {
       //return null;
    //}

}
