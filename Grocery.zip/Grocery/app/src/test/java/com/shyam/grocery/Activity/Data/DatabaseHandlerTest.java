package com.shyam.grocery.Activity.Data;

import org.junit.Test;

import static org.junit.Assert.*;

public class DatabaseHandlerTest {

    @Test
    public void onCreate() {
    }

    @Test
    public void onUpgrade() {
    }

    @Test
    public void addGrocery() {
    }

    @Test
    public void getGrocery() {
    }

    @Test
    public void getAllGrocery() {
    }

    @Test
    public void updateGrocery() {
    }

    @Test
    public void deletGrocery() {
    }

    @Test
    public void getGroceriesCount() {
    }
}